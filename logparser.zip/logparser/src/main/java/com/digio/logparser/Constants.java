package com.digio.logparser;

import java.util.concurrent.TimeUnit;

public class Constants {

  public static String URL_STARTFLAG = "] \"";
  public static Integer DEFAULT_TIMEOUT = 1;
  public static TimeUnit DEFAULT_TIMEOUT_TIMEUNIT = TimeUnit.MINUTES;
}
