package com.digio.logparser;

public class LogParserCli {

  public static void main(String[] args) {

    if (args.length != 1) {
      usage();
    } else {
      // parsing starts here
      LogParserService logParserService = new LogParserService();
      logParserService.parseFile(args[0]);

      // printing out
      System.out.println("Total Unique IP Addresses: " + logParserService.getNoOfUniqueIpAddresses());
      System.out.println();
      System.out.println("Top 3 Most Active Ip Address:");
      logParserService.getTopMostActiveIpAddress(3).stream()
          .forEach(System.out::println);
      System.out.println();
      System.out.println("Top 3 Most Visited Url:");
      logParserService.getTopMostVisitedUrl(3).stream()
          .forEach(System.out::println);

    }
  }

  public static void usage() {
    System.out.println("Usage:");
    System.out.println("java -jar <jarfile> <file to parse>");
    System.out.println();
    System.out.println("Example:");
    System.out.println("java -jar xxxx.jar example.log");
  }
}
