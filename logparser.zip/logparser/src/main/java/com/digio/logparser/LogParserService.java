package com.digio.logparser;

import static com.digio.logparser.Constants.DEFAULT_TIMEOUT;
import static com.digio.logparser.Constants.DEFAULT_TIMEOUT_TIMEUNIT;
import static com.digio.logparser.Constants.URL_STARTFLAG;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;

@AllArgsConstructor
public class LogParserService {

  private ConcurrentHashMap<String, Integer> ipMap;
  private ConcurrentHashMap<String, Integer> urlMap;

  public LogParserService() {
    this.ipMap = new ConcurrentHashMap<>();
    this.urlMap = new ConcurrentHashMap<>();
  }

  public void parseFile(String filePath) {
    ExecutorService executorService = Executors.newFixedThreadPool(10);// default initial capacity is 16

    if (StringUtils.isBlank(filePath)) {
      System.out.println("Invalid File Path");
    } else {

      try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {

        // loop till the end of the file
        String line;
        while ((line = br.readLine()) != null) {

          // for each line obtain the ip address and url in parallel (This might be overthinking, but I was just testing around here)
          final String newLineObject = line;

          executorService.submit(() -> {
            String ipAddress = getIpAddress(newLineObject);
            String url = getUrl(newLineObject);

            // add the ip address and the url to the map or increment the counter value
            ipMap.putIfAbsent(ipAddress, 0);
            ipMap.computeIfPresent(ipAddress, (key, value) -> value + 1);

            urlMap.putIfAbsent(url, 0);
            urlMap.computeIfPresent(url, (key, value) -> value + 1);
          });
        }

        executorService.shutdown();
        executorService.awaitTermination(DEFAULT_TIMEOUT, DEFAULT_TIMEOUT_TIMEUNIT);

      } catch (IOException | InterruptedException e) {
        System.out.println("Error encounter with mesage: " + e.getMessage());
      }
    }
  }

  // assumption: there will never be IPv6
  // assumption: the ip address will either be valid or not there at all, it can't be partial
  public String getIpAddress(String line) {

    if (StringUtils.isBlank(line)) {
      return null;
    } else {
      String[] strings = line.split(" ", 2);
      if (strings != null && strings.length > 1 && StringUtils.isNotBlank(strings[0])) {
        return strings[0];
      } else {
        return null;
      }
    }
  }

  // assumption: it is not possible to have ] before the datetime stamp
  // assumption: url will contains no space character
  public String getUrl(String line) {
    if (StringUtils.isBlank(line)) {
      return null;
    } else {
      int sI = line.indexOf(URL_STARTFLAG);
      if (sI == -1) {
        return null;
      } else {
        // after url start flag, there are exactly 2 spaces that surround the url
        String[] strings = line.substring(sI + URL_STARTFLAG.length()).split(" ", 3);
        if (strings != null && strings.length > 2 && StringUtils.isNotBlank(strings[1])) {
          return strings[1];
        } else {
          return null;
        }
      }
    }
  }

  public Integer getNoOfUniqueIpAddresses() {
    if (ipMap == null) {
      return 0;
    } else {
      return ipMap.size();
    }
  }

  public List<String> getTopMostVisitedUrl(Integer limit) {

    if (urlMap == null) {
      return Arrays.asList();
    } else {
      return urlMap.entrySet()
          .stream()
          // if the top 3 are equal, then let java randomly pick the order
          .sorted(Entry.<String, Integer>comparingByValue().reversed())
          .limit(limit)
          .map(entry -> entry.getKey())
          .collect(Collectors.toList());
    }
  }

  public List<String> getTopMostActiveIpAddress(Integer limit) {

    if (urlMap == null) {
      return Arrays.asList();
    } else {
      return ipMap.entrySet()
          .stream()
          // if the top 3 are equal, then let java randomly pick the order
          .sorted(Entry.<String, Integer>comparingByValue().reversed())
          .limit(limit)
          .map(entry -> entry.getKey())
          .collect(Collectors.toList());
    }
  }
}
