package com.digio.logparser;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.assertAll;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class LogParserServiceTest {

  private LogParserService logParserService;

  @BeforeEach
  public void setup() {
    ConcurrentHashMap<String, Integer> ipMap = new ConcurrentHashMap<>();
    ipMap.put("1.1.1.10", 10);
    ipMap.put("1.1.1.2", 1);
    ipMap.put("1.1.1.40", 13);
    ipMap.put("1.1.1.3", 20);
    ipMap.put("1.1.1.120", 45);
    ipMap.put("1.1.1.100", 90);

    ConcurrentHashMap<String, Integer> urlMap = new ConcurrentHashMap<>();
    urlMap.put("google.com", 110);
    urlMap.put("bing.com", 20);
    urlMap.put("blahblah.io", 4);
    urlMap.put("twigger.com", 25);
    urlMap.put("samsung.com", 90);

    logParserService = new LogParserService(ipMap, urlMap);
  }


  @Test
  public void getNoOfUniqueIpAddresses_validValuedMaps_shouldReturnNumber() {
    Integer noOfUniqueIpAddresses = logParserService.getNoOfUniqueIpAddresses();
    assertAll("Number of Unique Ip Addresses",
        () -> assertThat(noOfUniqueIpAddresses, notNullValue()),
        () -> assertThat(noOfUniqueIpAddresses, is(6))
    );
  }

  @Test
  public void getNoOfUniqueIpAddresses_emptyMaps_shouldReturnZero() {
    logParserService = new LogParserService();
    Integer noOfUniqueIpAddresses = logParserService.getNoOfUniqueIpAddresses();
    assertAll("Number of Unique Ip Addresses",
        () -> assertThat(noOfUniqueIpAddresses, notNullValue()),
        () -> assertThat(noOfUniqueIpAddresses, is(0))
    );
  }

  @Test
  public void getNoOfUniqueIpAddresses_nullMaps_shouldReturnZero() {
    logParserService = new LogParserService(null, null);
    Integer noOfUniqueIpAddresses = logParserService.getNoOfUniqueIpAddresses();
    assertAll("Number of Unique Ip Addresses",
        () -> assertThat(noOfUniqueIpAddresses, notNullValue()),
        () -> assertThat(noOfUniqueIpAddresses, is(0))
    );
  }


  @Test
  public void getTopMostVisitedUrl_validValuedMaps_shouldReturnList() {
    List<String> topMostVisitedUrl = logParserService.getTopMostVisitedUrl(3);
    assertAll("Top 3 Most Visited Url",
        () -> assertThat(topMostVisitedUrl, notNullValue()),
        () -> assertThat(topMostVisitedUrl.size(), is(3)),
        () -> assertThat(topMostVisitedUrl, contains(is("google.com"), is("samsung.com"), is("twigger.com")))
    );
  }

  @Test
  public void getTopMostVisitedUrl_emptyMaps_shouldReturnEmpty() {
    logParserService = new LogParserService();
    List<String> topMostVisitedUrl = logParserService.getTopMostVisitedUrl(3);
    assertAll("Top 3 Most Visited Url",
        () -> assertThat(topMostVisitedUrl, notNullValue()),
        () -> assertThat(topMostVisitedUrl.size(), is(0))
    );
  }

  @Test
  public void getTopMostVisitedUrl_nullMaps_shouldReturnEmpty() {
    logParserService = new LogParserService(null, null);
    List<String> topMostVisitedUrl = logParserService.getTopMostVisitedUrl(3);
    assertAll("Top 3 Most Visited Url",
        () -> assertThat(topMostVisitedUrl, notNullValue()),
        () -> assertThat(topMostVisitedUrl.size(), is(0))
    );
  }

  @Test
  public void getTopMostActiveIpAddress_validValuedMaps_shouldReturnList() {
    List<String> topMostActiveIpAddress = logParserService.getTopMostActiveIpAddress(3);
    assertAll("Top 3 Most Active Ip Addresses",
        () -> assertThat(topMostActiveIpAddress, notNullValue()),
        () -> assertThat(topMostActiveIpAddress.size(), is(3)),
        () -> assertThat(topMostActiveIpAddress, contains(is("1.1.1.100"), is("1.1.1.120"), is("1.1.1.3")))
    );
  }

  @Test
  public void getTopMostActiveIpAddress_emptyMaps_shouldReturnEmpty() {
    logParserService = new LogParserService();
    List<String> topMostActiveIpAddress = logParserService.getTopMostActiveIpAddress(3);
    assertAll("Top 3 Most Active Ip Addresses",
        () -> assertThat(topMostActiveIpAddress, notNullValue()),
        () -> assertThat(topMostActiveIpAddress.size(), is(0))
    );
  }

  @Test
  public void getTopMostActiveIpAddress_nullMaps_shouldReturnEmpty() {
    logParserService = new LogParserService(null, null);
    List<String> topMostActiveIpAddress = logParserService.getTopMostActiveIpAddress(3);
    assertAll("Top 3 Most Active Ip Addresses",
        () -> assertThat(topMostActiveIpAddress, notNullValue()),
        () -> assertThat(topMostActiveIpAddress.size(), is(0))
    );
  }

  @Test
  public void getIpAddress_validParam_shouldReturnCorrectIp() {

    String line = "177.71.128.21 - - [10/Jul/2018:22:21:28 +0200] \"GET /intranet-analytics/ HTTP/1.1\" "
        + "200 3574 \"-\" \"Mozilla/5.0 (X11; U; Linux x86_64; fr-FR) AppleWebKit/534.7 (KHTML, like Gecko) "
        + "Epiphany/2.30.6 Safari/534.7\"";
    String ipAddress = logParserService.getIpAddress(line);
    assertAll("IP Address",
        () -> assertThat(ipAddress, notNullValue()),
        () -> assertThat(ipAddress, is("177.71.128.21"))
    );
  }

  @Test
  public void getIpAddress_validParamNoIp_shouldReturnNull() {

    String line = " - - [10/Jul/2018:22:21:28 +0200] \"GET /intranet-analytics/ HTTP/1.1\" "
        + "200 3574 \"-\" \"Mozilla/5.0 (X11; U; Linux x86_64; fr-FR) AppleWebKit/534.7 (KHTML, like Gecko) "
        + "Epiphany/2.30.6 Safari/534.7\"";
    String ipAddress = logParserService.getIpAddress(line);
    assertAll("IP Address",
        () -> assertThat(ipAddress, nullValue())
    );
  }

  @Test
  public void getUrl_validParam_shouldReturnCorrectUrl() {

    String line = "177.71.128.21 - - [10/Jul/2018:22:21:28 +0200] \"GET /intranet-analytics/ HTTP/1.1\" "
        + "200 3574 \"-\" \"Mozilla/5.0 (X11; U; Linux x86_64; fr-FR) AppleWebKit/534.7 (KHTML, like Gecko) "
        + "Epiphany/2.30.6 Safari/534.7\"";
    String url = logParserService.getUrl(line);
    assertAll("Url Path",
        () -> assertThat(url, notNullValue()),
        () -> assertThat(url, is("/intranet-analytics/"))
    );
  }

  @Test
  public void getUrl_validParamNoUrl_shouldReturnNull() {

    String line = " - - [10/Jul/2018:22:21:28 +0200] \"GET  HTTP/1.1\" "
        + "200 3574 \"-\" \"Mozilla/5.0 (X11; U; Linux x86_64; fr-FR) AppleWebKit/534.7 (KHTML, like Gecko) "
        + "Epiphany/2.30.6 Safari/534.7\"";
    String url = logParserService.getUrl(line);
    assertAll("Url Path",
        () -> assertThat(url, nullValue())
    );
  }

  @Test
  public void procesS_validParam_shouldReturnSuccess() {

    logParserService = new LogParserService();
    logParserService.parseFile(getClass().getClassLoader().getResource("example.log").getFile());

    Integer noOfUniqueIpAddresses = logParserService.getNoOfUniqueIpAddresses();
    List<String> topMostActiveIpAddresses = logParserService.getTopMostActiveIpAddress(3);
    List<String> topMostVisitedUrls = logParserService.getTopMostVisitedUrl(3);

    assertAll("Parse Result",
        () -> assertThat(noOfUniqueIpAddresses, is(11)),
        () -> assertThat(topMostActiveIpAddresses, notNullValue()),
        () -> assertThat(topMostActiveIpAddresses.size(), is(3)),
        () -> assertThat(topMostActiveIpAddresses,
            contains(is("177.71.128.21"), is("50.112.00.11"), is("168.41.191.40"))),
        () -> assertThat(topMostVisitedUrls, notNullValue()),
        () -> assertThat(topMostVisitedUrls.size(), is(3)),
        () -> assertThat(topMostVisitedUrls,
            contains(is("/intranet-analytics/"), is("/asset.js"), is("/docs/manage-websites/")))
    );
  }

  @Test
  public void procesS_nullParam_shouldReturnSuccess() {

    logParserService = new LogParserService();
    logParserService.parseFile(null);

    Integer noOfUniqueIpAddresses = logParserService.getNoOfUniqueIpAddresses();
    List<String> topMostActiveIpAddresses = logParserService.getTopMostActiveIpAddress(3);
    List<String> topMostVisitedUrls = logParserService.getTopMostVisitedUrl(3);

    assertAll("Parse Result",
        () -> assertThat(noOfUniqueIpAddresses, is(0)),
        () -> assertThat(topMostActiveIpAddresses, notNullValue()),
        () -> assertThat(topMostActiveIpAddresses.size(), is(0)),
        () -> assertThat(topMostVisitedUrls, notNullValue()),
        () -> assertThat(topMostVisitedUrls.size(), is(0))
    );
  }

  @Test
  public void procesS_validParamMinimalFile_shouldReturnSuccess() {

    logParserService = new LogParserService();
    logParserService.parseFile(getClass().getClassLoader().getResource("mini-example.log").getFile());

    Integer noOfUniqueIpAddresses = logParserService.getNoOfUniqueIpAddresses();
    List<String> topMostActiveIpAddresses = logParserService.getTopMostActiveIpAddress(3);
    List<String> topMostVisitedUrls = logParserService.getTopMostVisitedUrl(3);

    assertAll("Parse Result",
        () -> assertThat(noOfUniqueIpAddresses, is(2)),
        () -> assertThat(topMostActiveIpAddresses, notNullValue()),
        () -> assertThat(topMostActiveIpAddresses.size(), is(2)),
        () -> assertThat(topMostActiveIpAddresses,
            containsInAnyOrder(is("177.71.128.21"), is("168.41.191.40"))),
        () -> assertThat(topMostVisitedUrls, notNullValue()),
        () -> assertThat(topMostVisitedUrls.size(), is(2)),
        () -> assertThat(topMostVisitedUrls,
            containsInAnyOrder(is("/intranet-analytics/"), is("http://example.net/faq/")))
    );
  }
}
